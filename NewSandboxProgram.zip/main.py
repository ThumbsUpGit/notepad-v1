import tkinter as tk
from tkinter import font

def main_menu():
    root = tk.Tk()
    root.title("Rounded Rectangle with Circle Button")
    root.configure(bg='black')

    # Canvas
    canvas_width = 1920
    canvas_height = 1080
    canvas = tk.Canvas(root, width=canvas_width, height=canvas_height, bg="black", highlightthickness=0)
    canvas.pack()

    # Circle event handlers
    def on_circle_click(event):
        print("I do nothing yet bozo")

    def on_circle_enter(event):
        canvas.itemconfig(circle, fill="dim gray")

    def on_circle_leave(event):
        canvas.itemconfig(circle, fill="grey")

    # Custom font
    try:
        custom_font = font.Font(family='Comfortaa', size=12, weight='bold')
    except tk.TclError:
        custom_font = font.Font(family='Helvetica', size=12, weight='bold')

    # Label
    label = tk.Label(root, text='Hello, Tkinter!', font=custom_font, fg="white", bg="black")
    label.pack(pady=10)

    # Rounded rectangle helpers
    def create_rounded_rectangle(canvas, x1, y1, x2, y2, radius, **kwargs):
        points = (
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1
        )
        return canvas.create_polygon(points, smooth=True, **kwargs)

    # Rectangle positions
    x1, y1, x2, y2 = 100, 30, 500, 460
    radius = 30
    create_rounded_rectangle(canvas, x1 - 100, y1 - 70, x2 + 700, y2 + 700, radius + 10,
                             fill="grey20", outline="grey10", width=2)
    create_rounded_rectangle(canvas, x1, y1, x2, y2, radius,
                             fill="grey60", outline="grey55", width=2)

    # Circle button
    circle_radius = 25
    circle_x = (x1 + x2) // 4.4
    circle_y = (y1 + y2) // 6

    circle = canvas.create_oval(
        circle_x - circle_radius, circle_y - circle_radius,
        circle_x + circle_radius, circle_y + circle_radius,
        fill="grey", outline="grey", width=2
    )

    # Add plus symbol
    canvas.create_text(circle_x, circle_y, text="+", fill="white", font=custom_font)

    # Bind events
    canvas.tag_bind(circle, "<Button-1>", on_circle_click)
    canvas.tag_bind(circle, "<Enter>", on_circle_enter)
    canvas.tag_bind(circle, "<Leave>", on_circle_leave)

    root.mainloop()


if __name__ == '__main__':
    main_menu()